<?php include 'templates/header.php'; ?>
<h2>Бронирование успешно!</h2>
<a class='btn' href='index.php'>На главную</a>
<?php include 'templates/footer.php'; ?>