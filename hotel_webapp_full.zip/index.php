<?php include 'templates/header.php'; ?>
<section class='hero'><h2>SunHotel</h2><a class='btn' href='booking.php'>Забронировать</a></section>
<?php include 'templates/footer.php'; ?>