<!DOCTYPE html><html lang='ru'><head><meta charset='UTF-8'>
<title>SunHotel</title><link rel='stylesheet' href='style.css'></head><body>
<header><h1>SunHotel</h1><nav>
<a href='index.php'>Главная</a>
<a href='rooms.php'>Номера</a>
<a href='booking.php'>Бронирование</a>
<a href='contact.php'>Контакты</a>
<a href='admin/index.php'>Админ</a>
</nav></header>