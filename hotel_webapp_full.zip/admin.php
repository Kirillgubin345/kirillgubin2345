<?php session_start(); include 'templates/header.php'; ?>
<h2>Админ-панель</h2>
<?php if(!isset($_SESSION['admin'])): ?>
<form method='POST' action='login.php'>
<input name='login' placeholder='Логин'>
<input name='password' placeholder='Пароль' type='password'>
<button class='btn'>Войти</button>
</form>
<?php else: ?>
<a href='bookings_list.php'>Заявки</a><br><a href='logout.php'>Выйти</a>
<?php endif; ?>
<?php include 'templates/footer.php'; ?>