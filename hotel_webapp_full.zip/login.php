<?php
session_start();
$db=new SQLite3('hotel.db');
$res=$db->query("SELECT * FROM admin WHERE login='{$_POST['login']}' AND password='{$_POST['password']}'");
if($res->fetchArray()){ $_SESSION['admin']=1; }
header('Location: admin.php');
?>