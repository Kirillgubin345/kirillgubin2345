<?php include '../db.php'; ?>
<h2>Админ-панель</h2>
<a href='bookings.php'>Просмотр бронирований</a>
