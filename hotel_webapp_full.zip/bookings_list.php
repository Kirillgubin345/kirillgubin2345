<?php session_start(); if(!isset($_SESSION['admin'])) die('Нет доступа');
include 'templates/header.php';
echo "<h2>Все бронирования</h2>";
$db=new SQLite3('hotel.db');
$res=$db->query("SELECT * FROM bookings");
while($r=$res->fetchArray()){
 echo "<div class='room-card'>{$r['name']} — {$r['room']} — {$r['checkin']} - {$r['checkout']}</div>";
}
include 'templates/footer.php';
?>