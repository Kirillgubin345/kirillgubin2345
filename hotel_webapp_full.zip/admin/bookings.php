<?php include '../db.php'; ?>
<h2>Все бронирования</h2>
<table border='1' cellpadding='6'>
<tr><th>ID</th><th>Имя</th><th>Email</th><th>Номер</th><th>Заезд</th><th>Выезд</th></tr>
<?php
$res=$conn->query("SELECT * FROM bookings");
while($r=$res->fetch_assoc()){
echo "<tr><td>{$r['id']}</td><td>{$r['name']}</td><td>{$r['email']}</td><td>{$r['room']}</td><td>{$r['checkin']}</td><td>{$r['checkout']}</td></tr>";
}
?>
</table>
