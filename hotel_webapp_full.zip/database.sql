
CREATE DATABASE IF NOT EXISTS hotel_db;
USE hotel_db;

CREATE TABLE bookings (
 id INT AUTO_INCREMENT PRIMARY KEY,
 name VARCHAR(255),
 email VARCHAR(255),
 room VARCHAR(50),
 checkin DATE,
 checkout DATE
);
