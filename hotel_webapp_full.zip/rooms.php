<?php include 'templates/header.php'; ?>
<h2>Номера</h2>
<?php
$db=new SQLite3('hotel.db');
$res=$db->query('SELECT * FROM rooms');
while($r=$res->fetchArray()){
 echo "<div class='room-card'><h3>{$r['name']}</h3><p>{$r['description']}</p><b>{$r['price']} ₽</b></div>";
}
?>
<?php include 'templates/footer.php'; ?>