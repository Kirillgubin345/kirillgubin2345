<?php
$db=new SQLite3('hotel.db');
$stmt=$db->prepare('INSERT INTO bookings(name,email,room,checkin,checkout) VALUES(?,?,?,?,?)');
$stmt->bindValue(1,$_POST['name']);
$stmt->bindValue(2,$_POST['email']);
$stmt->bindValue(3,$_POST['room']);
$stmt->bindValue(4,$_POST['checkin']);
$stmt->bindValue(5,$_POST['checkout']);
$stmt->execute();
header('Location: success.php');
?>