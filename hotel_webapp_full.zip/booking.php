<?php include 'templates/header.php'; ?>
<h2>Бронирование</h2>
<form method='POST' action='save_booking.php'>
<input name='name' placeholder='Имя' required>
<input name='email' placeholder='Email' required>
<select name='room'>
<option>Стандарт</option><option>Люкс</option><option>Президентский</option>
</select>
<label>Заезд</label><input type='date' name='checkin'>
<label>Выезд</label><input type='date' name='checkout'>
<button class='btn'>Отправить</button>
</form>
<?php include 'templates/footer.php'; ?>