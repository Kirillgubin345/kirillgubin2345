<?php include 'header.php'; ?>
<section class='contacts'><h2>Контакты</h2><p>Москва, ул. Центральная, 10</p></section>
<?php include 'footer.php'; ?>